package com.healthcare.model;

import com.healthcare.util.AppException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class RoleTest {
    @Test
    void parsesCaseInsensitivelyAndTrims() {
        assertEquals(Role.DOCTOR, Role.parse(" doctor "));
        assertEquals(Role.ADMIN, Role.parse("ADMIN"));
    }

    @Test
    void rejectsUnknownOrMissingRoles() {
        assertThrows(AppException.class, () -> Role.parse("nurse"));
        assertThrows(AppException.class, () -> Role.parse(null));
    }

    @Test
    void eachRoleHasItsOwnLandingPages() {
        assertEquals("/admin/dashboard", Role.ADMIN.getHomePath());
        assertEquals("/patient/history", Role.PATIENT.getAppointmentsPath());
    }
}
