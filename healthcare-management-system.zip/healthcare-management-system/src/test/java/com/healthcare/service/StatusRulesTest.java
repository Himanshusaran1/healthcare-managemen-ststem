package com.healthcare.service;

import com.healthcare.model.Role;
import com.healthcare.util.AppException;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StatusRulesTest {
    @Test
    void patientMayOnlyCancel() {
        assertDoesNotThrow(() -> StatusRules.validate(Role.PATIENT, "PENDING", "CANCELLED"));
        assertThrows(AppException.class, () -> StatusRules.validate(Role.PATIENT, "PENDING", "CONFIRMED"));
        assertThrows(AppException.class, () -> StatusRules.validate(Role.PATIENT, "CONFIRMED", "COMPLETED"));
    }

    @Test
    void doctorCanConfirmThenComplete() {
        assertDoesNotThrow(() -> StatusRules.validate(Role.DOCTOR, "PENDING", "CONFIRMED"));
        assertDoesNotThrow(() -> StatusRules.validate(Role.DOCTOR, "CONFIRMED", "COMPLETED"));
    }

    @Test
    void pendingAppointmentCannotBeCompletedDirectly() {
        AppException e = assertThrows(AppException.class, () -> StatusRules.validate(Role.DOCTOR, "PENDING", "COMPLETED"));
        assertEquals("Only confirmed appointments can be completed.", e.getMessage());
    }

    @Test
    void adminCannotCompleteAppointments() {
        assertThrows(AppException.class, () -> StatusRules.validate(Role.ADMIN, "CONFIRMED", "COMPLETED"));
        assertDoesNotThrow(() -> StatusRules.validate(Role.ADMIN, "PENDING", "CONFIRMED"));
    }

    @Test
    void closedAppointmentsCannotChange() {
        AppException e = assertThrows(AppException.class, () -> StatusRules.validate(Role.DOCTOR, "CANCELLED", "CONFIRMED"));
        assertEquals("This appointment is already cancelled.", e.getMessage());
        assertThrows(AppException.class, () -> StatusRules.validate(Role.PATIENT, "COMPLETED", "CANCELLED"));
    }

    @Test
    void unknownOrMissingTargetIsRejected() {
        assertThrows(AppException.class, () -> StatusRules.validate(Role.DOCTOR, "PENDING", "DELETED"));
        assertThrows(AppException.class, () -> StatusRules.validate(Role.DOCTOR, "PENDING", null));
    }
}
