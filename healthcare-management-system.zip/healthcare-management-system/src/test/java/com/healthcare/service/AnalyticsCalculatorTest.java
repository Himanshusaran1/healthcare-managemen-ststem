package com.healthcare.service;

import com.healthcare.model.Appointment;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class AnalyticsCalculatorTest {
    private static Appointment appt(String doctor, String status, String date) {
        Appointment a = new Appointment();
        a.setDoctorName(doctor);
        a.setStatus(status);
        a.setDate(LocalDate.parse(date));
        return a;
    }

    private final List<Appointment> sample = List.of(
        appt("Dr. A", "COMPLETED", "2026-09-10"),
        appt("Dr. A", "CANCELLED", "2026-09-20"),
        appt("Dr. B", "PENDING", "2026-10-02"));

    @Test
    void groupsByMonthInChronologicalOrder() {
        Map<String, Long> months = AnalyticsCalculator.byMonth(sample);
        assertEquals(List.of("2026-09", "2026-10"), List.copyOf(months.keySet()));
        assertEquals(2L, months.get("2026-09"));
        assertEquals(1L, months.get("2026-10"));
    }

    @Test
    void countsPerDoctorAndStatus() {
        assertEquals(2L, AnalyticsCalculator.byDoctor(sample).get("Dr. A"));
        assertEquals(1L, AnalyticsCalculator.byStatus(sample).get("PENDING"));
    }

    @Test
    void maxOfEmptyMapIsZero() {
        assertEquals(0L, AnalyticsCalculator.max(Map.of()));
        assertEquals(2L, AnalyticsCalculator.max(AnalyticsCalculator.byDoctor(sample)));
    }
}
