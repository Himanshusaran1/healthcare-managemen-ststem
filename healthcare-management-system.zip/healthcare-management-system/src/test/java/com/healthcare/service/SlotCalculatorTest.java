package com.healthcare.service;

import com.healthcare.model.Availability;
import org.junit.jupiter.api.Test;

import java.time.LocalTime;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class SlotCalculatorTest {
    private static LocalTime t(int h, int m) { return LocalTime.of(h, m); }
    private static Availability window(int fromH, int fromM, int toH, int toM) { return new Availability(1, t(fromH, fromM), t(toH, toM)); }

    @Test
    void generatesSlotsInsideAWindow() {
        List<LocalTime> slots = SlotCalculator.generate(List.of(window(9, 0, 11, 0)), 30, Set.of(), false, t(0, 0));
        assertEquals(List.of(t(9, 0), t(9, 30), t(10, 0), t(10, 30)), slots);
    }

    @Test
    void excludesBookedTimes() {
        List<LocalTime> slots = SlotCalculator.generate(List.of(window(9, 0, 11, 0)), 30, Set.of(t(9, 30), t(10, 30)), false, t(0, 0));
        assertEquals(List.of(t(9, 0), t(10, 0)), slots);
    }

    @Test
    void excludesTimesAlreadyPastWhenBookingToday() {
        List<LocalTime> slots = SlotCalculator.generate(List.of(window(9, 0, 11, 0)), 30, Set.of(), true, t(9, 45));
        assertEquals(List.of(t(10, 0), t(10, 30)), slots);
    }

    @Test
    void lastSlotMustFitInsideTheWindow() {
        List<LocalTime> slots = SlotCalculator.generate(List.of(window(9, 0, 10, 15)), 30, Set.of(), false, t(0, 0));
        assertEquals(List.of(t(9, 0), t(9, 30)), slots);
    }

    @Test
    void mergesMultipleWindowsInOrder() {
        List<LocalTime> slots = SlotCalculator.generate(List.of(window(14, 0, 15, 0), window(9, 0, 10, 0)), 30, Set.of(), false, t(0, 0));
        assertEquals(List.of(t(9, 0), t(9, 30), t(14, 0), t(14, 30)), slots);
    }

    @Test
    void noWindowsMeansNoSlots() {
        assertTrue(SlotCalculator.generate(List.of(), 30, Set.of(), false, t(0, 0)).isEmpty());
    }

    @Test
    void windowEndingAtMidnightDoesNotLoopForever() {
        List<LocalTime> slots = SlotCalculator.generate(List.of(window(23, 0, 23, 59)), 30, Set.of(), false, t(0, 0));
        assertEquals(List.of(t(23, 0)), slots);
    }

    @Test
    void rejectsNonPositiveDuration() {
        assertThrows(IllegalArgumentException.class, () -> SlotCalculator.generate(List.of(), 0, Set.of(), false, t(0, 0)));
    }

    @Test
    void parseDurationFallsBackToThirtyMinutes() {
        assertEquals(45, SlotCalculator.parseDuration("45"));
        assertEquals(30, SlotCalculator.parseDuration("abc"));
        assertEquals(30, SlotCalculator.parseDuration("1"));
        assertEquals(30, SlotCalculator.parseDuration("9999"));
        assertEquals(30, SlotCalculator.parseDuration(null));
    }
}
