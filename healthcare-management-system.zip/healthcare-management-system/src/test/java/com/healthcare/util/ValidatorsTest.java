package com.healthcare.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ValidatorsTest {
    @Test
    void acceptsNormalEmails() {
        assertTrue(Validators.isValidEmail("riya@healthcare.test"));
        assertTrue(Validators.isValidEmail("  a.b@c.org  "));
    }

    @Test
    void rejectsBadEmails() {
        assertFalse(Validators.isValidEmail(null));
        assertFalse(Validators.isValidEmail("no-at-sign"));
        assertFalse(Validators.isValidEmail("a@b"));
        assertFalse(Validators.isValidEmail("a b@c.com"));
    }

    @Test
    void passwordNeedsEightCharacters() {
        assertFalse(Validators.isValidPassword("short7!"));
        assertTrue(Validators.isValidPassword("eight888"));
        assertFalse(Validators.isValidPassword(null));
    }

    @Test
    void nameLengthIsChecked() {
        assertFalse(Validators.isValidName("A"));
        assertTrue(Validators.isValidName("Al"));
        assertFalse(Validators.isValidName("x".repeat(101)));
    }

    @Test
    void validateNewUserReportsTheFirstProblem() {
        assertEquals("Enter a name (2-100 characters).", assertThrows(AppException.class, () -> Validators.validateNewUser("", "a@b.co", "password1")).getMessage());
        assertEquals("Enter a valid email address.", assertThrows(AppException.class, () -> Validators.validateNewUser("Riya", "bad", "password1")).getMessage());
        assertEquals("Password must be at least 8 characters.", assertThrows(AppException.class, () -> Validators.validateNewUser("Riya", "a@b.co", "123")).getMessage());
        assertDoesNotThrow(() -> Validators.validateNewUser("Riya", "a@b.co", "password1"));
    }
}
