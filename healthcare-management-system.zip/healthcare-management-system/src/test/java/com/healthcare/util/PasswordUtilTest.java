package com.healthcare.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/** Uses the real jBCrypt library (cost 12, so each hash takes a fraction of a second). */
class PasswordUtilTest {
    @Test
    void hashIsNotThePlainPassword() {
        String hash = PasswordUtil.hash("Secret#123");
        assertNotEquals("Secret#123", hash);
        assertTrue(hash.startsWith("$2"));
    }

    @Test
    void correctPasswordVerifiesAndWrongOneDoesNot() {
        String hash = PasswordUtil.hash("Secret#123");
        assertTrue(PasswordUtil.verify("Secret#123", hash));
        assertFalse(PasswordUtil.verify("secret#123", hash));
    }

    @Test
    void sameInputGivesDifferentHashesBecauseOfSalt() {
        assertNotEquals(PasswordUtil.hash("Secret#123"), PasswordUtil.hash("Secret#123"));
    }

    @Test
    void malformedOrMissingHashNeverVerifies() {
        assertFalse(PasswordUtil.verify("x", "not-a-bcrypt-hash"));
        assertFalse(PasswordUtil.verify("x", null));
        assertFalse(PasswordUtil.verify(null, "$2a$12$abcdefghijklmnopqrstuuABCDEFGHIJKLMNOPQRSTUVWXYZ012"));
    }
}
