package com.healthcare.dao;

import com.healthcare.model.MedicalRecord;

import java.sql.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class MedicalRecordDAO extends BaseDAO {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private static final String SELECT =
        "SELECT r.id, pu.name AS patient_name, du.name AS doctor_name, r.diagnosis, r.allergies, r.notes, r.created_at, "
      + "(SELECT GROUP_CONCAT(CONCAT(pr.medication, IF(pr.dosage IS NULL OR pr.dosage = '', '', CONCAT(' (', pr.dosage, ')'))) SEPARATOR '; ') "
      + "   FROM prescriptions pr WHERE pr.record_id = r.id) AS prescriptions "
      + "FROM medical_records r "
      + "JOIN patients p ON p.id = r.patient_id JOIN users pu ON pu.id = p.user_id "
      + "JOIN doctors d ON d.id = r.doctor_id JOIN users du ON du.id = d.user_id ";

    private List<MedicalRecord> query(String where, int param) {
        List<MedicalRecord> list = new ArrayList<>();
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(SELECT + where + " ORDER BY r.created_at DESC")) {
            ps.setInt(1, param);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    MedicalRecord m = new MedicalRecord();
                    m.setId(rs.getInt("id"));
                    m.setPatientName(rs.getString("patient_name"));
                    m.setDoctorName(rs.getString("doctor_name"));
                    m.setDiagnosis(rs.getString("diagnosis"));
                    m.setAllergies(rs.getString("allergies"));
                    m.setNotes(rs.getString("notes"));
                    m.setPrescriptions(rs.getString("prescriptions"));
                    m.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime().format(FMT));
                    list.add(m);
                }
            }
            return list;
        } catch (SQLException e) { throw db(e); }
    }

    public List<MedicalRecord> findByPatient(int patientId) { return query("WHERE r.patient_id = ?", patientId); }

    /** Records of every patient who has an appointment with this doctor. */
    public List<MedicalRecord> findForDoctorsPatients(int doctorId) {
        return query("WHERE r.patient_id IN (SELECT patient_id FROM appointments WHERE doctor_id = ?)", doctorId);
    }

    /** Inserts a record and its optional prescription atomically. */
    public int add(int patientId, int doctorId, String diagnosis, String allergies, String notes,
                   String medication, String dosage) {
        try (Connection c = conn()) {
            c.setAutoCommit(false);
            try {
                int recordId;
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO medical_records (patient_id, doctor_id, diagnosis, allergies, notes) VALUES (?,?,?,?,?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1, patientId);
                    ps.setInt(2, doctorId);
                    ps.setString(3, diagnosis);
                    ps.setString(4, allergies);
                    ps.setString(5, notes);
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        keys.next();
                        recordId = keys.getInt(1);
                    }
                }
                if (medication != null && !medication.isBlank()) {
                    try (PreparedStatement ps = c.prepareStatement(
                            "INSERT INTO prescriptions (record_id, medication, dosage) VALUES (?,?,?)")) {
                        ps.setInt(1, recordId);
                        ps.setString(2, medication);
                        ps.setString(3, dosage);
                        ps.executeUpdate();
                    }
                }
                c.commit();
                return recordId;
            } catch (SQLException | RuntimeException e) {
                c.rollback();
                throw e;
            }
        } catch (SQLException e) { throw db(e); }
    }
}
