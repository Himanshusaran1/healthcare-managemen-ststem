package com.healthcare.dao;

import com.healthcare.model.Appointment;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

/**
 * Appointment SQL. Methods that take a Connection are used inside a transaction owned by
 * AppointmentService (needed for the double-booking check); the rest open their own connection.
 */
public class AppointmentDAO extends BaseDAO implements Listable<Appointment> {

    private static final String SELECT =
        "SELECT a.id, a.patient_id, a.doctor_id, pu.name AS patient_name, du.name AS doctor_name, d.specialty, "
      + "a.appt_date, a.appt_time, a.reason, a.status, a.notes "
      + "FROM appointments a "
      + "JOIN patients p ON p.id = a.patient_id JOIN users pu ON pu.id = p.user_id "
      + "JOIN doctors d ON d.id = a.doctor_id JOIN users du ON du.id = d.user_id ";
    private static final String ORDER = " ORDER BY a.appt_date DESC, a.appt_time DESC";

    private Appointment map(ResultSet rs) throws SQLException {
        Appointment a = new Appointment();
        a.setId(rs.getInt("id"));
        a.setPatientId(rs.getInt("patient_id"));
        a.setDoctorId(rs.getInt("doctor_id"));
        a.setPatientName(rs.getString("patient_name"));
        a.setDoctorName(rs.getString("doctor_name"));
        a.setSpecialty(rs.getString("specialty"));
        a.setDate(rs.getDate("appt_date").toLocalDate());
        a.setTime(rs.getTime("appt_time").toLocalTime());
        a.setReason(rs.getString("reason"));
        a.setStatus(rs.getString("status"));
        a.setNotes(rs.getString("notes"));
        return a;
    }

    private List<Appointment> query(String sql, Integer param) {
        List<Appointment> list = new ArrayList<>();
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql)) {
            if (param != null) ps.setInt(1, param);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
            return list;
        } catch (SQLException e) { throw db(e); }
    }

    @Override public List<Appointment> findAll() { return query(SELECT + ORDER, null); }
    public List<Appointment> findByDoctor(int doctorId) { return query(SELECT + "WHERE a.doctor_id = ?" + ORDER, doctorId); }
    public List<Appointment> findByPatient(int patientId) { return query(SELECT + "WHERE a.patient_id = ?" + ORDER, patientId); }

    public Optional<Appointment> findById(int id) {
        List<Appointment> list = query(SELECT + "WHERE a.id = ?", id);
        return list.isEmpty() ? Optional.empty() : Optional.of(list.get(0));
    }

    /** Times already taken (not cancelled) for a doctor on a date. */
    public Set<LocalTime> bookedTimes(int doctorId, LocalDate date) {
        String sql = "SELECT appt_time FROM appointments WHERE doctor_id = ? AND appt_date = ? AND status <> 'CANCELLED'";
        Set<LocalTime> times = new HashSet<>();
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, doctorId);
            ps.setDate(2, java.sql.Date.valueOf(date));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) times.add(rs.getTime(1).toLocalTime());
            }
            return times;
        } catch (SQLException e) { throw db(e); }
    }

    /** Locks the doctor row so two simultaneous bookings for the same doctor are processed one at a time. */
    public boolean lockDoctor(Connection c, int doctorId) throws SQLException {
        try (PreparedStatement ps = c.prepareStatement("SELECT id FROM doctors WHERE id = ? FOR UPDATE")) {
            ps.setInt(1, doctorId);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }

    public boolean slotTaken(Connection c, int doctorId, LocalDate date, LocalTime time) throws SQLException {
        String sql = "SELECT 1 FROM appointments WHERE doctor_id = ? AND appt_date = ? AND appt_time = ? AND status <> 'CANCELLED'";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, doctorId);
            ps.setDate(2, java.sql.Date.valueOf(date));
            ps.setTime(3, Time.valueOf(time));
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }

    public int insert(Connection c, int patientId, int doctorId, LocalDate date, LocalTime time, String reason) throws SQLException {
        String sql = "INSERT INTO appointments (patient_id, doctor_id, appt_date, appt_time, reason, status) VALUES (?,?,?,?,?,'PENDING')";
        try (PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, patientId);
            ps.setInt(2, doctorId);
            ps.setDate(3, java.sql.Date.valueOf(date));
            ps.setTime(4, Time.valueOf(time));
            ps.setString(5, reason);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return keys.getInt(1);
            }
        }
    }

    public void updateStatus(int id, String status, String notes) {
        String sql = "UPDATE appointments SET status = ?, notes = COALESCE(?, notes) WHERE id = ?";
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setString(2, notes);
            ps.setInt(3, id);
            ps.executeUpdate();
        } catch (SQLException e) { throw db(e); }
    }

    /** Patients (id -> name) who have at least one appointment with this doctor. */
    public Map<Integer, String> patientsOfDoctor(int doctorId) {
        String sql = "SELECT DISTINCT p.id, u.name FROM appointments a JOIN patients p ON p.id = a.patient_id "
                   + "JOIN users u ON u.id = p.user_id WHERE a.doctor_id = ? ORDER BY u.name";
        Map<Integer, String> map = new LinkedHashMap<>();
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, doctorId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) map.put(rs.getInt(1), rs.getString(2));
            }
            return map;
        } catch (SQLException e) { throw db(e); }
    }

    public boolean doctorHasPatient(int doctorId, int patientId) {
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(
                "SELECT 1 FROM appointments WHERE doctor_id = ? AND patient_id = ? LIMIT 1")) {
            ps.setInt(1, doctorId);
            ps.setInt(2, patientId);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        } catch (SQLException e) { throw db(e); }
    }
}
