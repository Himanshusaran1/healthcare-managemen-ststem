package com.healthcare.dao;

import com.healthcare.model.Availability;
import com.healthcare.model.Doctor;

import java.sql.*;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class DoctorDAO extends BaseDAO implements Listable<Doctor> {

    /** Active doctors only, so deactivated accounts cannot be booked. */
    @Override
    public List<Doctor> findAll() {
        String sql = "SELECT d.id, u.name, d.specialty FROM doctors d JOIN users u ON u.id = d.user_id "
                   + "WHERE u.status = 'ACTIVE' ORDER BY u.name";
        List<Doctor> list = new ArrayList<>();
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(new Doctor(rs.getInt("id"), rs.getString("name"), rs.getString("specialty")));
            return list;
        } catch (SQLException e) { throw db(e); }
    }

    public List<Availability> availability(int doctorId, int dayOfWeek) {
        String sql = "SELECT day_of_week, start_time, end_time FROM doctor_availability "
                   + "WHERE doctor_id = ? AND day_of_week = ? ORDER BY start_time";
        List<Availability> list = new ArrayList<>();
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, doctorId);
            ps.setInt(2, dayOfWeek);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Availability(rs.getInt("day_of_week"),
                        rs.getTime("start_time").toLocalTime(), rs.getTime("end_time").toLocalTime()));
                }
            }
            return list;
        } catch (SQLException e) { throw db(e); }
    }

    public void addAvailability(int doctorId, int dayOfWeek, LocalTime start, LocalTime end) {
        String sql = "INSERT IGNORE INTO doctor_availability (doctor_id, day_of_week, start_time, end_time) VALUES (?,?,?,?)";
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, doctorId);
            ps.setInt(2, dayOfWeek);
            ps.setTime(3, Time.valueOf(start));
            ps.setTime(4, Time.valueOf(end));
            ps.executeUpdate();
        } catch (SQLException e) { throw db(e); }
    }
}
