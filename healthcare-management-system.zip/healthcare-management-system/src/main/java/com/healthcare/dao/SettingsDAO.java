package com.healthcare.dao;

import java.sql.*;

public class SettingsDAO extends BaseDAO {
    public String get(String key, String defaultValue) {
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(
                "SELECT setting_value FROM system_settings WHERE setting_key = ?")) {
            ps.setString(1, key);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getString(1) : defaultValue;
            }
        } catch (SQLException e) { throw db(e); }
    }
}
