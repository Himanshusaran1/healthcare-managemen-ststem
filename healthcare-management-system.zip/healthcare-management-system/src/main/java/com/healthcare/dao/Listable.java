package com.healthcare.dao;

import java.util.List;

/** Contract for DAOs that can return every row of their entity type. */
public interface Listable<T> {
    List<T> findAll();
}
