package com.healthcare.dao;

import com.healthcare.util.AppException;
import com.healthcare.util.DBUtil;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/** Shared plumbing for all DAOs: connection access and uniform SQL error handling. */
public abstract class BaseDAO {
    private static final Logger LOG = Logger.getLogger(BaseDAO.class.getName());

    protected Connection conn() throws SQLException {
        return DBUtil.getConnection();
    }

    /** Logs the technical cause and returns a safe exception for the UI. */
    protected AppException db(SQLException e) {
        LOG.log(Level.SEVERE, "Database error", e);
        return new AppException("A database error occurred. Please try again.", e);
    }
}
