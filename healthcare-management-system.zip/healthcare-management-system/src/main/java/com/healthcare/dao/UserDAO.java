package com.healthcare.dao;

import com.healthcare.model.Role;
import com.healthcare.model.User;
import com.healthcare.util.AppException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** All SQL for users (and their doctor/patient profile rows). Prepared statements only. */
public class UserDAO extends BaseDAO implements Listable<User> {

    private static final String SELECT =
        "SELECT u.id, u.name, u.email, u.password_hash, u.role, u.status, u.phone, "
      + "COALESCE(d.id, p.id, 0) AS profile_id "
      + "FROM users u LEFT JOIN doctors d ON d.user_id = u.id LEFT JOIN patients p ON p.user_id = u.id ";

    private User map(ResultSet rs) throws SQLException {
        User u = new User();
        u.setId(rs.getInt("id"));
        u.setProfileId(rs.getInt("profile_id"));
        u.setName(rs.getString("name"));
        u.setEmail(rs.getString("email"));
        u.setPasswordHash(rs.getString("password_hash"));
        u.setRole(Role.valueOf(rs.getString("role")));
        u.setStatus(rs.getString("status"));
        u.setPhone(rs.getString("phone"));
        return u;
    }

    public Optional<User> findByEmail(String email) {
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(SELECT + "WHERE u.email = ?")) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(map(rs)) : Optional.empty();
            }
        } catch (SQLException e) { throw db(e); }
    }

    public Optional<User> findById(int id) {
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(SELECT + "WHERE u.id = ?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(map(rs)) : Optional.empty();
            }
        } catch (SQLException e) { throw db(e); }
    }

    @Override
    public List<User> findAll() {
        List<User> users = new ArrayList<>();
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement(SELECT + "ORDER BY u.id");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) users.add(map(rs));
            return users;
        } catch (SQLException e) { throw db(e); }
    }

    /**
     * Creates the user AND the matching doctor/patient profile row in one transaction,
     * so we never end up with a login that has no profile.
     */
    public int create(User u, String passwordHash, String specialty) {
        try (Connection c = conn()) {
            c.setAutoCommit(false);
            try {
                int userId;
                try (PreparedStatement ps = c.prepareStatement(
                        "INSERT INTO users (name, email, password_hash, role, status, phone) VALUES (?,?,?,?,?,?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, u.getName());
                    ps.setString(2, u.getEmail());
                    ps.setString(3, passwordHash);
                    ps.setString(4, u.getRole().name());
                    ps.setString(5, "ACTIVE");
                    ps.setString(6, u.getPhone());
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        keys.next();
                        userId = keys.getInt(1);
                    }
                }
                if (u.getRole() == Role.DOCTOR) {
                    try (PreparedStatement ps = c.prepareStatement(
                            "INSERT INTO doctors (user_id, specialty) VALUES (?, ?)")) {
                        ps.setInt(1, userId);
                        ps.setString(2, specialty == null || specialty.isBlank() ? "General Medicine" : specialty);
                        ps.executeUpdate();
                    }
                } else if (u.getRole() == Role.PATIENT) {
                    try (PreparedStatement ps = c.prepareStatement("INSERT INTO patients (user_id) VALUES (?)")) {
                        ps.setInt(1, userId);
                        ps.executeUpdate();
                    }
                }
                c.commit();
                return userId;
            } catch (SQLException | RuntimeException e) {
                c.rollback();
                throw e;
            }
        } catch (SQLIntegrityConstraintViolationException e) {
            throw new AppException("That email is already registered.", e);
        } catch (SQLException e) {
            throw db(e);
        }
    }

    public void setStatus(int id, String status) {
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement("UPDATE users SET status = ? WHERE id = ?")) {
            ps.setString(1, status);
            ps.setInt(2, id);
            ps.executeUpdate();
        } catch (SQLException e) { throw db(e); }
    }

    public void delete(int id) {
        try (Connection c = conn(); PreparedStatement ps = c.prepareStatement("DELETE FROM users WHERE id = ?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLIntegrityConstraintViolationException e) {
            throw new AppException("This user has appointments or records and cannot be deleted. Deactivate the account instead.", e);
        } catch (SQLException e) { throw db(e); }
    }
}
