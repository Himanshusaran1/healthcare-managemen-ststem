package com.healthcare.controller;

import com.healthcare.model.Appointment;
import com.healthcare.model.User;
import com.healthcare.model.Role;
import com.healthcare.service.AppointmentService;
import com.healthcare.service.RecordService;
import com.healthcare.service.UserService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

/** One servlet serves the three dashboards; the filter already guarantees the role matches the URL. */
@WebServlet({"/admin/dashboard", "/doctor/dashboard", "/patient/dashboard"})
public class DashboardServlet extends BaseServlet {
    private final AppointmentService appts = new AppointmentService();
    private final UserService users = new UserService();
    private final RecordService records = new RecordService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User u = currentUser(req);
        List<Appointment> list = appts.listFor(u);
        req.setAttribute("statusCounts", appts.statusCounts(list));
        req.setAttribute("todayCount", appts.countToday(list));

        switch (u.getRole()) {
            case ADMIN -> {
                List<User> all = users.list();
                req.setAttribute("totalUsers", all.size());
                req.setAttribute("totalDoctors", users.countByRole(all, Role.DOCTOR));
                req.setAttribute("totalPatients", users.countByRole(all, Role.PATIENT));
                req.setAttribute("recent", list.stream().limit(5).collect(Collectors.toList()));
            }
            case DOCTOR -> {
                req.setAttribute("upcomingCount", appts.upcoming(list).size());
                req.setAttribute("patientCount", appts.distinctPatients(list));
                req.setAttribute("upcoming", appts.upcoming(list).stream().limit(5).collect(Collectors.toList()));
            }
            case PATIENT -> {
                List<Appointment> up = appts.upcoming(list);
                req.setAttribute("next", up.isEmpty() ? null : up.get(0));
                req.setAttribute("totalAppointments", list.size());
                req.setAttribute("recentRecords", records.forPatient(u).stream().limit(3).collect(Collectors.toList()));
            }
        }
        forward(req, resp, u.getRole().name().toLowerCase() + "/dashboard");
    }
}
