package com.healthcare.controller;

import com.healthcare.model.User;
import com.healthcare.service.RecordService;
import com.healthcare.util.AppException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

/** Doctors: view/add records of their own patients. Patients: read-only timeline of their own history. */
@WebServlet({"/doctor/records", "/patient/medical"})
public class RecordServlet extends BaseServlet {
    private final RecordService service = new RecordService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User u = currentUser(req);
        if (req.getServletPath().equals("/doctor/records")) {
            req.setAttribute("records", service.forDoctor(u));
            req.setAttribute("patients", service.patientsOf(u));
            forward(req, resp, "doctor/records");
        } else {
            req.setAttribute("records", service.forPatient(u));
            forward(req, resp, "patient/medical");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        // Only /doctor/* POSTs reach here for doctors; the filter returns 403 for other roles.
        User doctor = currentUser(req);
        try {
            service.addRecord(doctor, intParam(req, "patientId"), param(req, "diagnosis"), param(req, "allergies"),
                              param(req, "notes"), param(req, "medication"), param(req, "dosage"));
            flash(req, "success", "Medical record saved.");
        } catch (AppException e) {
            flash(req, "danger", e.getMessage());
        }
        redirect(req, resp, "/doctor/records");
    }
}
