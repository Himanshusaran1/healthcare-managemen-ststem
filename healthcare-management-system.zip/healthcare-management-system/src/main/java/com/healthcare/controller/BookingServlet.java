package com.healthcare.controller;

import com.healthcare.dao.DoctorDAO;
import com.healthcare.model.Doctor;
import com.healthcare.model.User;
import com.healthcare.service.AppointmentService;
import com.healthcare.util.AppException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.List;

/** Patient booking: step 1 choose doctor + date (GET), step 2 choose a free slot and confirm (POST). */
@WebServlet("/patient/book")
public class BookingServlet extends BaseServlet {
    private final AppointmentService service = new AppointmentService();
    private final DoctorDAO doctorDao = new DoctorDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Doctor> doctors = doctorDao.findAll();
        req.setAttribute("doctors", doctors);
        req.setAttribute("today", LocalDate.now().toString());

        String doctorId = req.getParameter("doctorId");
        String date = req.getParameter("date");
        if (doctorId != null && !doctorId.isBlank() && date != null && !date.isBlank()) {
            try {
                int id = Integer.parseInt(doctorId);
                req.setAttribute("slots", service.availableSlots(id, LocalDate.parse(date)));
                for (Doctor d : doctors) {
                    if (d.getId() == id) req.setAttribute("selectedDoctor", d);
                }
            } catch (NumberFormatException | DateTimeParseException e) {
                req.setAttribute("error", "Choose a doctor and a valid date.");
            }
        }
        forward(req, resp, "patient/book");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User patient = currentUser(req);
        try {
            int doctorId = intParam(req, "doctorId");
            LocalDate date = LocalDate.parse(param(req, "date"));
            LocalTime time = LocalTime.parse(param(req, "time"));
            int id = service.book(patient.getProfileId(), doctorId, date, time, req.getParameter("reason"));
            flash(req, "success", "Appointment booked. Your appointment ID is A-" + id + ".");
            redirect(req, resp, "/patient/history");
        } catch (DateTimeParseException e) {
            flash(req, "danger", "Choose a valid date and time.");
            redirect(req, resp, "/patient/book");
        } catch (AppException e) {
            flash(req, "danger", e.getMessage());
            redirect(req, resp, "/patient/book");
        }
    }
}
