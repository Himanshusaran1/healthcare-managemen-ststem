package com.healthcare.controller;

import com.healthcare.model.User;
import com.healthcare.service.AuthService;
import com.healthcare.util.AppException;
import com.healthcare.util.CsrfUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends BaseServlet {
    private final AuthService auth = new AuthService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User user = currentUser(req);
        if (user != null) { redirect(req, resp, user.getRole().getHomePath()); return; }
        req.getRequestDispatcher("/login.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String email = param(req, "email");
        try {
            User user = auth.login(email, req.getParameter("password"));

            HttpSession old = req.getSession(false);
            if (old != null) old.invalidate();          // new session ID after login (prevents session fixation)
            HttpSession session = req.getSession(true);
            session.setAttribute("user", user);
            session.setAttribute("csrf", CsrfUtil.newToken());
            session.setMaxInactiveInterval(30 * 60);
            redirect(req, resp, user.getRole().getHomePath());
        } catch (AppException e) {
            req.setAttribute("error", e.getMessage());
            req.setAttribute("email", email);
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            req.getRequestDispatcher("/login.jsp").forward(req, resp);
        }
    }
}
