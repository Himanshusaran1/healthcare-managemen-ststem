package com.healthcare.controller;

import com.healthcare.model.Appointment;
import com.healthcare.service.AnalyticsCalculator;
import com.healthcare.service.AppointmentService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

/** Admin analytics: appointments by month, per doctor and by status (simple CSS bar charts, no JS library). */
@WebServlet("/admin/analytics")
public class AnalyticsServlet extends BaseServlet {
    private final AppointmentService service = new AppointmentService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        List<Appointment> all = service.listFor(currentUser(req));
        var byMonth = AnalyticsCalculator.byMonth(all);
        var byDoctor = AnalyticsCalculator.byDoctor(all);
        var byStatus = AnalyticsCalculator.byStatus(all);
        req.setAttribute("byMonth", byMonth);
        req.setAttribute("byDoctor", byDoctor);
        req.setAttribute("byStatus", byStatus);
        req.setAttribute("maxMonth", AnalyticsCalculator.max(byMonth));
        req.setAttribute("maxDoctor", AnalyticsCalculator.max(byDoctor));
        req.setAttribute("maxStatus", AnalyticsCalculator.max(byStatus));
        req.setAttribute("total", all.size());
        forward(req, resp, "admin/analytics");
    }
}
