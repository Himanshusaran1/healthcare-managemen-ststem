package com.healthcare.controller;

import com.healthcare.model.User;
import com.healthcare.service.UserService;
import com.healthcare.util.AppException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet("/admin/users")
public class AdminUserServlet extends BaseServlet {
    private final UserService service = new UserService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("users", service.list());
        forward(req, resp, "admin/users");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User actor = currentUser(req);
        try {
            switch (param(req, "action")) {
                case "create" -> {
                    service.create(param(req, "name"), param(req, "email"), req.getParameter("password"),
                                   param(req, "role"), param(req, "specialty"));
                    flash(req, "success", "User created.");
                }
                case "toggle" -> { service.toggleStatus(actor, intParam(req, "id")); flash(req, "success", "User status updated."); }
                case "delete" -> { service.delete(actor, intParam(req, "id")); flash(req, "success", "User deleted."); }
                default -> throw new AppException("Unknown action.");
            }
        } catch (AppException e) {
            flash(req, "danger", e.getMessage());
        }
        redirect(req, resp, "/admin/users");
    }
}
