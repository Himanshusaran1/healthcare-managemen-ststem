package com.healthcare.controller;

import com.healthcare.model.User;
import com.healthcare.service.AppointmentService;
import com.healthcare.util.AppException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

/** Lists appointments for the logged-in role and handles confirm / complete / cancel actions. */
@WebServlet({"/admin/appointments", "/doctor/appointments", "/patient/history", "/appointments/status"})
public class AppointmentServlet extends BaseServlet {
    private final AppointmentService service = new AppointmentService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        User u = currentUser(req);
        if (req.getServletPath().equals("/appointments/status")) { // action URL opened directly
            redirect(req, resp, u.getRole().getAppointmentsPath());
            return;
        }
        req.setAttribute("appointments", service.listFor(u));
        String view = switch (u.getRole()) {
            case ADMIN -> "admin/appointments";
            case DOCTOR -> "doctor/appointments";
            case PATIENT -> "patient/history";
        };
        forward(req, resp, view);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        User u = currentUser(req);
        try {
            service.changeStatus(u, intParam(req, "id"), param(req, "status"), req.getParameter("notes"));
            flash(req, "success", "Appointment updated.");
        } catch (AppException e) {
            flash(req, "danger", e.getMessage());
        }
        redirect(req, resp, u.getRole().getAppointmentsPath());
    }
}
