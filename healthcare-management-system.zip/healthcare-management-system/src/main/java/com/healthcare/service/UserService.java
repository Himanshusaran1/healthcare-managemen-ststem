package com.healthcare.service;

import com.healthcare.dao.UserDAO;
import com.healthcare.model.Role;
import com.healthcare.model.User;
import com.healthcare.util.AppException;
import com.healthcare.util.PasswordUtil;
import com.healthcare.util.Validators;

import java.util.List;

/** Admin-side user management with server-side validation. */
public class UserService {
    private final UserDAO userDao = new UserDAO();

    public List<User> list() { return userDao.findAll(); }

    public long countByRole(List<User> users, Role role) {
        return users.stream().filter(u -> u.getRole() == role).count();
    }

    public void create(String name, String email, String password, String roleText, String specialty) {
        Validators.validateNewUser(name, email, password);
        Role role = Role.parse(roleText);

        User u = new User();
        u.setName(name.trim());
        u.setEmail(email.trim().toLowerCase());
        u.setRole(role);
        userDao.create(u, PasswordUtil.hash(password), specialty == null ? null : specialty.trim());
    }

    public void delete(User actor, int userId) {
        if (actor.getId() == userId) throw new AppException("You cannot delete your own account.");
        userDao.delete(userId);
    }

    public void toggleStatus(User actor, int userId) {
        if (actor.getId() == userId) throw new AppException("You cannot deactivate your own account.");
        User target = userDao.findById(userId).orElseThrow(() -> new AppException("User not found."));
        userDao.setStatus(userId, target.isActive() ? "INACTIVE" : "ACTIVE");
    }
}
