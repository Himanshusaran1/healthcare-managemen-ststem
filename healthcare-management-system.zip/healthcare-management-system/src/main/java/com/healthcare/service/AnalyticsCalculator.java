package com.healthcare.service;

import com.healthcare.model.Appointment;

import java.time.YearMonth;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.function.Function;
import java.util.stream.Collectors;

/** Grouping and counting used by the admin analytics page. Pure functions, unit tested. */
public final class AnalyticsCalculator {
    private AnalyticsCalculator() { }

    public static Map<String, Long> countBy(List<Appointment> list, Function<Appointment, String> key) {
        return list.stream().collect(Collectors.groupingBy(key, TreeMap::new, Collectors.counting()));
    }

    public static Map<String, Long> byMonth(List<Appointment> list) {
        return countBy(list, a -> YearMonth.from(a.getDate()).toString());
    }

    public static Map<String, Long> byDoctor(List<Appointment> list) {
        return countBy(list, Appointment::getDoctorName);
    }

    public static Map<String, Long> byStatus(List<Appointment> list) {
        return countBy(list, Appointment::getStatus);
    }

    public static long max(Map<String, Long> counts) {
        return counts.values().stream().mapToLong(Long::longValue).max().orElse(0);
    }
}
