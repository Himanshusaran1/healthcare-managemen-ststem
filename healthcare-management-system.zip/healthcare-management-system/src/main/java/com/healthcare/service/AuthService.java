package com.healthcare.service;

import com.healthcare.dao.UserDAO;
import com.healthcare.model.User;
import com.healthcare.util.AppException;
import com.healthcare.util.PasswordUtil;

/** Login logic. The same message is returned for every failure so attackers cannot probe which emails exist. */
public class AuthService {
    private static final String BAD_LOGIN = "Invalid email or password.";
    private final UserDAO userDao = new UserDAO();

    public User login(String email, String password) {
        if (email == null || email.isBlank() || password == null || password.isEmpty()) {
            throw new AppException("Enter your email and password.");
        }
        User user = userDao.findByEmail(email.trim().toLowerCase()).orElseThrow(() -> new AppException(BAD_LOGIN));
        if (!user.isActive() || !PasswordUtil.verify(password, user.getPasswordHash())) {
            throw new AppException(BAD_LOGIN);
        }
        user.clearSecret(); // never keep the hash in the session
        return user;
    }
}
