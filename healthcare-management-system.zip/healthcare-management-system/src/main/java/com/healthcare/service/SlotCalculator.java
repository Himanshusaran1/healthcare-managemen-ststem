package com.healthcare.service;

import com.healthcare.model.Availability;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * Pure slot-generation logic (no database, no clock), so it can be unit tested.
 * AppointmentService supplies the doctor's working windows, the booked times and the current time.
 */
public final class SlotCalculator {
    private SlotCalculator() { }

    /**
     * @param windows working windows for the weekday
     * @param minutes appointment length in minutes (must be positive)
     * @param booked  times already taken
     * @param today   true when the date being booked is today
     * @param now     current time (only used when today is true)
     * @return free start times in ascending order; the whole appointment must fit inside a window
     */
    public static List<LocalTime> generate(List<Availability> windows, int minutes, Set<LocalTime> booked,
                                           boolean today, LocalTime now) {
        if (minutes <= 0) throw new IllegalArgumentException("minutes must be positive");
        TreeSet<LocalTime> slots = new TreeSet<>();
        for (Availability w : windows) {
            LocalTime t = w.getStart();
            while (true) {
                LocalTime end = t.plusMinutes(minutes);
                if (end.isBefore(t) || end.isAfter(w.getEnd())) break; // wrapped past midnight or does not fit
                boolean past = today && !t.isAfter(now);
                if (!booked.contains(t) && !past) slots.add(t);
                t = end;
            }
        }
        return new ArrayList<>(slots);
    }

    /** Reads the appointment length from a setting value; falls back to 30 minutes if missing or unreasonable. */
    public static int parseDuration(String value) {
        try {
            int m = Integer.parseInt(value.trim());
            return m >= 5 && m <= 240 ? m : 30;
        } catch (NumberFormatException | NullPointerException e) {
            return 30;
        }
    }
}
