package com.healthcare.service;

import com.healthcare.model.Role;
import com.healthcare.util.AppException;

import java.util.Set;

/** Who may move an appointment to which status, and from which current status. Pure logic, unit tested. */
public final class StatusRules {
    private StatusRules() { }

    public static Set<String> allowedTargets(Role role) {
        return switch (role) {
            case ADMIN -> Set.of("CONFIRMED", "CANCELLED");
            case DOCTOR -> Set.of("CONFIRMED", "COMPLETED", "CANCELLED");
            case PATIENT -> Set.of("CANCELLED");
        };
    }

    /** Throws AppException with a user-safe message when the change is not allowed. */
    public static void validate(Role role, String current, String target) {
        if (target == null || !allowedTargets(role).contains(target)) throw new AppException("You cannot do that.");
        boolean open = "PENDING".equals(current) || "CONFIRMED".equals(current);
        if (!open) throw new AppException("This appointment is already " + String.valueOf(current).toLowerCase() + ".");
        if ("COMPLETED".equals(target) && !"CONFIRMED".equals(current)) {
            throw new AppException("Only confirmed appointments can be completed.");
        }
    }
}
