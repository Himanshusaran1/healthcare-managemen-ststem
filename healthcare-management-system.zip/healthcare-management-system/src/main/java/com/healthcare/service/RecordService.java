package com.healthcare.service;

import com.healthcare.dao.AppointmentDAO;
import com.healthcare.dao.MedicalRecordDAO;
import com.healthcare.model.MedicalRecord;
import com.healthcare.model.User;
import com.healthcare.util.AppException;

import java.util.List;
import java.util.Map;

/** Medical record access rules: patients see only their own; doctors only their own patients'. */
public class RecordService {
    private final MedicalRecordDAO recordDao = new MedicalRecordDAO();
    private final AppointmentDAO apptDao = new AppointmentDAO();

    public List<MedicalRecord> forPatient(User patient) { return recordDao.findByPatient(patient.getProfileId()); }
    public List<MedicalRecord> forDoctor(User doctor) { return recordDao.findForDoctorsPatients(doctor.getProfileId()); }
    public Map<Integer, String> patientsOf(User doctor) { return apptDao.patientsOfDoctor(doctor.getProfileId()); }

    public void addRecord(User doctor, int patientId, String diagnosis, String allergies, String notes,
                          String medication, String dosage) {
        if (diagnosis == null || diagnosis.isBlank()) throw new AppException("Diagnosis is required.");
        if (diagnosis.length() > 255 || (allergies != null && allergies.length() > 255)) throw new AppException("Diagnosis and allergies must be 255 characters or fewer.");
        if (!apptDao.doctorHasPatient(doctor.getProfileId(), patientId)) {
            throw new AppException("You can only add records for your own patients.");
        }
        recordDao.add(patientId, doctor.getProfileId(), diagnosis.trim(), allergies, notes, medication, dosage);
    }
}
