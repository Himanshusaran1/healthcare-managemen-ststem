package com.healthcare.filter;

import com.healthcare.model.Role;
import com.healthcare.model.User;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/**
 * Server-side security gate for every request:
 *  1. public paths (login, assets) pass through,
 *  2. everything else needs a logged-in session,
 *  3. /admin/*, /doctor/*, /patient/* require the matching role (403 otherwise),
 *  4. every POST must carry the session's CSRF token.
 */
@WebFilter("/*")
public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        String path = req.getRequestURI().substring(req.getContextPath().length());

        resp.setHeader("X-Content-Type-Options", "nosniff");
        resp.setHeader("X-Frame-Options", "DENY");

        if (isPublic(path)) {
            chain.doFilter(request, response);
            return;
        }

        HttpSession session = req.getSession(false);
        User user = session == null ? null : (User) session.getAttribute("user");
        if (user == null) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        Role required = requiredRole(path);
        if (required != null && user.getRole() != required) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        if ("POST".equalsIgnoreCase(req.getMethod()) && !csrfValid(req, session)) {
            resp.sendError(HttpServletResponse.SC_FORBIDDEN);
            return;
        }

        resp.setHeader("Cache-Control", "no-store"); // keep medical pages out of browser caches
        chain.doFilter(request, response);
    }

    private boolean isPublic(String path) {
        return path.equals("/") || path.equals("/index.jsp") || path.equals("/login") || path.equals("/login.jsp")
            || path.startsWith("/assets/");
    }

    private Role requiredRole(String path) {
        if (path.startsWith("/admin/")) return Role.ADMIN;
        if (path.startsWith("/doctor/")) return Role.DOCTOR;
        if (path.startsWith("/patient/")) return Role.PATIENT;
        return null; // e.g. /appointments/status, /logout: any logged-in user (service layer re-checks ownership)
    }

    private boolean csrfValid(HttpServletRequest req, HttpSession session) {
        String expected = (String) session.getAttribute("csrf");
        String sent = req.getParameter("_csrf");
        if (expected == null || sent == null) return false;
        return MessageDigest.isEqual(expected.getBytes(StandardCharsets.UTF_8), sent.getBytes(StandardCharsets.UTF_8));
    }
}
