package com.healthcare.model;

import java.time.LocalTime;

/** One working window for a doctor on a weekday (1 = Monday ... 7 = Sunday). */
public class Availability {
    private final int dayOfWeek;
    private final LocalTime start;
    private final LocalTime end;

    public Availability(int dayOfWeek, LocalTime start, LocalTime end) {
        this.dayOfWeek = dayOfWeek; this.start = start; this.end = end;
    }
    public int getDayOfWeek() { return dayOfWeek; }
    public LocalTime getStart() { return start; }
    public LocalTime getEnd() { return end; }
}
