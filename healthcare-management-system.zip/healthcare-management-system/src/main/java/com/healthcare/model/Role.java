package com.healthcare.model;

import com.healthcare.util.AppException;

/** The three user roles, each knowing its landing page and appointment page. */
public enum Role {
    ADMIN("/admin/dashboard", "/admin/appointments"),
    DOCTOR("/doctor/dashboard", "/doctor/appointments"),
    PATIENT("/patient/dashboard", "/patient/history");

    private final String homePath;
    private final String appointmentsPath;

    Role(String homePath, String appointmentsPath) {
        this.homePath = homePath;
        this.appointmentsPath = appointmentsPath;
    }

    public String getHomePath() { return homePath; }
    public String getAppointmentsPath() { return appointmentsPath; }

    /** Parses user input safely, throwing a friendly exception instead of IllegalArgumentException. */
    public static Role parse(String value) {
        if (value == null) throw new AppException("Please choose a role.");
        try {
            return valueOf(value.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new AppException("Invalid role.");
        }
    }
}
