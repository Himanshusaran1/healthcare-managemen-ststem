package com.healthcare.model;

/** A person who can log in. profileId is the doctors.id or patients.id for that user (0 for admins). */
public class User {
    private int id;
    private int profileId;
    private String name;
    private String email;
    private String passwordHash;
    private String phone;
    private String status;
    private Role role;

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getProfileId() { return profileId; }
    public void setProfileId(int profileId) { this.profileId = profileId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }

    /** Used by JSP/EL, e.g. ${sessionScope.user.roleName eq 'ADMIN'}. */
    public String getRoleName() { return role == null ? "" : role.name(); }
    public boolean isActive() { return "ACTIVE".equals(status); }

    /** Remove the hash before the object is stored in the HTTP session. */
    public void clearSecret() { this.passwordHash = null; }
}
