package com.healthcare.util;

import java.security.SecureRandom;
import java.util.Base64;

/** Generates the per-session CSRF token that every POST form must send back as "_csrf". */
public final class CsrfUtil {
    private static final SecureRandom RANDOM = new SecureRandom();

    private CsrfUtil() { }

    public static String newToken() {
        byte[] bytes = new byte[32];
        RANDOM.nextBytes(bytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
}
