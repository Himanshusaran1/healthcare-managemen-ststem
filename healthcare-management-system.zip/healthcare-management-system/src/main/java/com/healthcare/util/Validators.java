package com.healthcare.util;

import java.util.regex.Pattern;

/** Server-side input validation shared by services. Pure functions, unit tested. */
public final class Validators {
    private static final Pattern EMAIL = Pattern.compile("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");
    public static final int MIN_PASSWORD_LENGTH = 8;

    private Validators() { }

    public static boolean isValidEmail(String email) {
        return email != null && EMAIL.matcher(email.trim()).matches();
    }

    public static boolean isValidName(String name) {
        return name != null && name.trim().length() >= 2 && name.trim().length() <= 100;
    }

    public static boolean isValidPassword(String password) {
        return password != null && password.length() >= MIN_PASSWORD_LENGTH;
    }

    /** Throws AppException with a friendly message for the first problem found. */
    public static void validateNewUser(String name, String email, String password) {
        if (!isValidName(name)) throw new AppException("Enter a name (2-100 characters).");
        if (!isValidEmail(email)) throw new AppException("Enter a valid email address.");
        if (!isValidPassword(password)) throw new AppException("Password must be at least 8 characters.");
    }
}
