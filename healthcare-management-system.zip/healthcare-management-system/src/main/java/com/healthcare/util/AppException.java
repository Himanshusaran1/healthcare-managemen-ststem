package com.healthcare.util;

/**
 * Unchecked exception for errors that are safe to show to the user
 * (validation failures, business-rule violations) or that wrap a lower-level cause.
 */
public class AppException extends RuntimeException {
    public AppException(String message) { super(message); }
    public AppException(String message, Throwable cause) { super(message, cause); }
}
