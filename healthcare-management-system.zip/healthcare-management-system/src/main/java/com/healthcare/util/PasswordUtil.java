package com.healthcare.util;

import org.mindrot.jbcrypt.BCrypt;

/** Thin wrapper around jBCrypt so the rest of the code never touches the library directly. */
public final class PasswordUtil {
    private static final int COST = 12;

    private PasswordUtil() { }

    public static String hash(String plain) {
        return BCrypt.hashpw(plain, BCrypt.gensalt(COST));
    }

    public static boolean verify(String plain, String hash) {
        try {
            return plain != null && hash != null && BCrypt.checkpw(plain, hash);
        } catch (IllegalArgumentException e) { // malformed hash
            return false;
        }
    }
}
