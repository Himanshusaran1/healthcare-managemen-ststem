package com.healthcare.util;

import com.healthcare.dao.DoctorDAO;
import com.healthcare.dao.UserDAO;
import com.healthcare.model.Role;
import com.healthcare.model.User;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

import java.time.LocalTime;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * DEVELOPMENT ONLY. When seed.dev.users=true in db.properties and the users table is empty,
 * creates sample accounts (password taken from seed.dev.password) and working hours for the doctors.
 * Passwords are hashed with BCrypt; no plaintext password is stored in the database or in source code.
 */
@WebListener
public class DevSeeder implements ServletContextListener {
    private static final Logger LOG = Logger.getLogger(DevSeeder.class.getName());

    @Override
    public void contextInitialized(ServletContextEvent event) {
        try {
            if (!DBUtil.getBoolean("seed.dev.users", false)) return;
            String password = DBUtil.get("seed.dev.password", "");
            if (password.length() < 8) { LOG.warning("seed.dev.password missing or too short; skipping sample data."); return; }

            UserDAO users = new UserDAO();
            if (!users.findAll().isEmpty()) return; // never touch a database that already has users

            String hash = PasswordUtil.hash(password);
            create(users, hash, "Admin User", "admin@healthcare.test", Role.ADMIN, null);
            create(users, hash, "Dr. Arjun Mehta", "dr.mehta@healthcare.test", Role.DOCTOR, "Cardiology");
            create(users, hash, "Dr. Sana Iqbal", "dr.iqbal@healthcare.test", Role.DOCTOR, "Dermatology");
            create(users, hash, "Riya Sharma", "riya@healthcare.test", Role.PATIENT, null);
            create(users, hash, "Neha Gupta", "neha@healthcare.test", Role.PATIENT, null);

            DoctorDAO doctors = new DoctorDAO();
            for (String email : new String[] {"dr.mehta@healthcare.test", "dr.iqbal@healthcare.test"}) {
                int doctorId = users.findByEmail(email).orElseThrow().getProfileId();
                for (int day = 1; day <= 5; day++) { // Monday to Friday
                    doctors.addAvailability(doctorId, day, LocalTime.of(9, 0), LocalTime.of(13, 0));
                }
            }
            LOG.info("Development sample accounts created. Disable seed.dev.users before any real use.");
        } catch (RuntimeException e) {
            LOG.log(Level.SEVERE, "Development seeding failed (the app will still start)", e);
        }
    }

    private void create(UserDAO dao, String hash, String name, String email, Role role, String specialty) {
        User u = new User();
        u.setName(name);
        u.setEmail(email);
        u.setRole(role);
        dao.create(u, hash, specialty);
    }
}
