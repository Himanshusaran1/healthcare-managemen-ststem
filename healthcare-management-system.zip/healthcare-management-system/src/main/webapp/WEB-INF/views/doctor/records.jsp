<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Patient records"/>
<%@ include file="/WEB-INF/views/common/header.jsp" %>
<h1 class="h4 mb-3">Patient records</h1>
<div class="card mb-4"><div class="card-body">
  <h2 class="h6">Add a record</h2>
  <c:choose>
  <c:when test="${empty patients}"><p class="text-muted mb-0">You can add records once a patient has booked with you.</p></c:when>
  <c:otherwise>
  <form method="post" action="${ctx}/doctor/records" class="row g-2">
    <input type="hidden" name="_csrf" value="<c:out value='${sessionScope.csrf}'/>">
    <div class="col-md-4"><label class="form-label" for="pid">Patient</label>
      <select class="form-select" id="pid" name="patientId" required>
        <c:forEach var="p" items="${patients}"><option value="${p.key}"><c:out value="${p.value}"/></option></c:forEach>
      </select></div>
    <div class="col-md-4"><label class="form-label" for="dg">Diagnosis</label><input class="form-control" id="dg" name="diagnosis" required maxlength="255"></div>
    <div class="col-md-4"><label class="form-label" for="al">Allergies</label><input class="form-control" id="al" name="allergies" maxlength="255"></div>
    <div class="col-md-4"><label class="form-label" for="md">Medication</label><input class="form-control" id="md" name="medication" maxlength="120"></div>
    <div class="col-md-4"><label class="form-label" for="ds">Dosage</label><input class="form-control" id="ds" name="dosage" maxlength="120"></div>
    <div class="col-12"><label class="form-label" for="nt">Clinical notes</label><textarea class="form-control" id="nt" name="notes" rows="2"></textarea></div>
    <div class="col-12"><button class="btn btn-primary" type="submit">Save record</button></div>
  </form>
  </c:otherwise>
  </c:choose>
</div></div>
<div class="card"><div class="card-body">
  <input type="search" class="form-control mb-3" style="max-width:320px" placeholder="Search records…" aria-label="Search records" data-filter-table="#recTable">
  <div class="table-responsive"><table class="table" id="recTable">
    <thead><tr><th>Patient</th><th>Diagnosis</th><th>Allergies</th><th>Prescriptions</th><th>Notes</th><th>Recorded</th><th>Doctor</th></tr></thead>
    <tbody>
    <c:forEach var="r" items="${records}">
      <tr><td><c:out value="${r.patientName}"/></td><td><c:out value="${r.diagnosis}"/></td><td><c:out value="${r.allergies}"/></td>
          <td><c:out value="${r.prescriptions}"/></td><td><c:out value="${r.notes}"/></td><td>${r.createdAt}</td><td><c:out value="${r.doctorName}"/></td></tr>
    </c:forEach>
    <c:if test="${empty records}"><tr><td colspan="7" class="text-center text-muted py-4">No records yet.</td></tr></c:if>
    </tbody>
  </table></div>
</div></div>
<%@ include file="/WEB-INF/views/common/footer.jsp" %>
