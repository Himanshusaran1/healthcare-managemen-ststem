<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Doctor overview"/>
<%@ include file="/WEB-INF/views/common/header.jsp" %>
<h1 class="h4 mb-3">Welcome, <c:out value="${sessionScope.user.name}"/></h1>
<div class="row g-3 mb-4">
  <div class="col-6 col-lg-3"><div class="card stat"><b>${todayCount}</b><span>Today</span></div></div>
  <div class="col-6 col-lg-3"><div class="card stat t"><b>${upcomingCount}</b><span>Upcoming</span></div></div>
  <div class="col-6 col-lg-3"><div class="card stat t"><b>${patientCount}</b><span>Total patients</span></div></div>
  <div class="col-6 col-lg-3"><div class="card stat"><b><c:out value="${statusCounts['COMPLETED']}" default="0"/></b><span>Completed</span></div></div>
</div>
<div class="card"><div class="card-body">
  <h2 class="h6">Next appointments</h2>
  <table class="table table-sm"><thead><tr><th>ID</th><th>Patient</th><th>When</th><th>Reason</th><th>Status</th></tr></thead><tbody>
  <c:forEach var="a" items="${upcoming}">
    <tr><td>A-${a.id}</td><td><c:out value="${a.patientName}"/></td><td>${a.date} ${a.time}</td>
        <td><c:out value="${a.reason}"/></td><td><span class="badge status-${a.status}">${a.status}</span></td></tr>
  </c:forEach>
  <c:if test="${empty upcoming}"><tr><td colspan="5" class="text-muted text-center">Nothing scheduled.</td></tr></c:if>
  </tbody></table>
  <a href="${ctx}/doctor/appointments">Manage appointments</a>
</div></div>
<%@ include file="/WEB-INF/views/common/footer.jsp" %>
