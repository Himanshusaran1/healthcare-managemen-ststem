<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" isErrorPage="true" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<c:set var="code" value="${pageContext.errorData.statusCode}"/>
<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Error – CareLink</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="${ctx}/assets/css/style.css" rel="stylesheet"></head>
<body class="login-bg"><main class="container d-flex align-items-center justify-content-center min-vh-100">
<div class="card shadow-sm p-4 text-center" style="max-width:460px">
  <c:choose>
    <c:when test="${code == 403}"><h1 class="h3">Access denied</h1><p class="text-muted">Your account does not have permission to open this page.</p></c:when>
    <c:when test="${code == 404}"><h1 class="h3">Page not found</h1><p class="text-muted">The page you asked for does not exist.</p></c:when>
    <c:otherwise><h1 class="h3">Something went wrong</h1><p class="text-muted">An unexpected error occurred. Please try again later.</p></c:otherwise>
  </c:choose>
  <a class="btn btn-primary" href="${ctx}/login">Back to dashboard</a>
</div></main></body></html>
