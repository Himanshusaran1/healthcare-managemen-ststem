<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Book appointment"/>
<%@ include file="/WEB-INF/views/common/header.jsp" %>
<h1 class="h4 mb-3">Book an appointment</h1>
<c:if test="${not empty error}"><div class="alert alert-danger"><c:out value="${error}"/></div></c:if>
<div class="card mb-4"><div class="card-body">
  <h2 class="h6">1. Choose a doctor and date</h2>
  <input type="search" class="form-control mb-3" style="max-width:320px" placeholder="Search by name or specialty…" aria-label="Search doctors" data-filter-table="#docTable">
  <form method="get" action="${ctx}/patient/book">
    <table class="table" id="docTable"><tbody>
    <c:forEach var="d" items="${doctors}">
      <tr><td style="width:40px"><input type="radio" name="doctorId" id="d${d.id}" value="${d.id}" required ${d.id == param.doctorId ? 'checked' : ''}></td>
          <td><label for="d${d.id}"><c:out value="${d.name}"/></label></td><td class="text-muted"><c:out value="${d.specialty}"/></td></tr>
    </c:forEach>
    <c:if test="${empty doctors}"><tr><td class="text-muted">No doctors available.</td></tr></c:if>
    </tbody></table>
    <div class="d-flex gap-2 align-items-end">
      <div><label class="form-label" for="dt">Date</label><input class="form-control" id="dt" type="date" name="date" min="${today}" value="<c:out value='${param.date}'/>" required></div>
      <button class="btn btn-outline-primary" type="submit">Show available times</button>
    </div>
  </form>
</div></div>
<c:if test="${slots != null}">
<div class="card"><div class="card-body">
  <h2 class="h6">2. Pick a time with <c:out value="${selectedDoctor.name}"/> on <c:out value="${param.date}"/></h2>
  <c:choose>
  <c:when test="${empty slots}"><p class="text-muted mb-0">No free times on that date. Try another day.</p></c:when>
  <c:otherwise>
  <form method="post" action="${ctx}/patient/book">
    <input type="hidden" name="_csrf" value="<c:out value='${sessionScope.csrf}'/>">
    <input type="hidden" name="doctorId" value="<c:out value='${param.doctorId}'/>">
    <input type="hidden" name="date" value="<c:out value='${param.date}'/>">
    <div class="d-flex flex-wrap gap-2 mb-3">
      <c:forEach var="t" items="${slots}">
        <input type="radio" class="btn-check" name="time" id="t${t}" value="${t}" required>
        <label class="btn btn-outline-primary" for="t${t}">${t}</label>
      </c:forEach>
    </div>
    <label class="form-label" for="rs">Reason for visit</label>
    <textarea class="form-control mb-3" id="rs" name="reason" rows="2" maxlength="255" required></textarea>
    <button class="btn btn-primary" type="submit">Confirm booking</button>
  </form>
  </c:otherwise>
  </c:choose>
</div></div>
</c:if>
<%@ include file="/WEB-INF/views/common/footer.jsp" %>
