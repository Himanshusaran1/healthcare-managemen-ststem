<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="My overview"/>
<%@ include file="/WEB-INF/views/common/header.jsp" %>
<h1 class="h4 mb-3">Welcome, <c:out value="${sessionScope.user.name}"/></h1>
<div class="row g-3 mb-4">
  <div class="col-md-4"><div class="card stat"><span>Next appointment</span>
    <c:choose>
      <c:when test="${not empty next}"><b class="fs-5">${next.date} ${next.time}</b><span><c:out value="${next.doctorName}"/> · ${next.status}</span></c:when>
      <c:otherwise><b class="fs-5">None scheduled</b><a href="${ctx}/patient/book">Book one</a></c:otherwise>
    </c:choose></div></div>
  <div class="col-md-4"><div class="card stat t"><b>${totalAppointments}</b><span>Total appointments</span></div></div>
  <div class="col-md-4"><div class="card stat"><span>Status summary</span>
    <c:forEach var="e" items="${statusCounts}"><span>${e.key}: ${e.value}</span></c:forEach></div></div>
</div>
<div class="card"><div class="card-body">
  <h2 class="h6">Recent medical history</h2>
  <c:forEach var="r" items="${recentRecords}"><p class="mb-2"><b><c:out value="${r.diagnosis}"/></b> <small class="text-muted">${r.createdAt}, <c:out value="${r.doctorName}"/></small></p></c:forEach>
  <c:if test="${empty recentRecords}"><p class="text-muted mb-0">No records yet.</p></c:if>
</div></div>
<%@ include file="/WEB-INF/views/common/footer.jsp" %>
