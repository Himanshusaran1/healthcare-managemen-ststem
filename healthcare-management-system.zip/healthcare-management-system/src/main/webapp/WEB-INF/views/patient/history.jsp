<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Appointment history"/>
<%@ include file="/WEB-INF/views/common/header.jsp" %>
<h1 class="h4 mb-3">Appointment history</h1>
<%@ include file="/WEB-INF/views/common/appointment-table.jsp" %>
<%@ include file="/WEB-INF/views/common/footer.jsp" %>
