<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Medical history"/>
<%@ include file="/WEB-INF/views/common/header.jsp" %>
<h1 class="h4 mb-3">Medical history</h1>
<div class="card"><div class="card-body">
  <div class="timeline">
  <c:forEach var="r" items="${records}">
    <div class="timeline-item">
      <b><c:out value="${r.diagnosis}"/></b> <small class="text-muted">${r.createdAt} · <c:out value="${r.doctorName}"/></small>
      <c:if test="${not empty r.allergies}"><div>Allergies: <c:out value="${r.allergies}"/></div></c:if>
      <c:if test="${not empty r.prescriptions}"><div>Prescriptions: <c:out value="${r.prescriptions}"/></div></c:if>
      <c:if test="${not empty r.notes}"><div class="text-muted"><c:out value="${r.notes}"/></div></c:if>
    </div>
  </c:forEach>
  </div>
  <c:if test="${empty records}"><p class="text-muted mb-0">No medical records yet.</p></c:if>
</div></div>
<%@ include file="/WEB-INF/views/common/footer.jsp" %>
