<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Analytics"/>
<%@ include file="/WEB-INF/views/common/header.jsp" %>
<h1 class="h4 mb-1">Performance analytics</h1>
<p class="text-muted">Based on ${total} appointment(s) in the database.</p>
<div class="row g-3">
  <div class="col-lg-6"><div class="card"><div class="card-body">
    <h2 class="h6">Appointments by month</h2>
    <c:forEach var="e" items="${byMonth}">
      <div class="bar-row"><span class="bar-label"><c:out value="${e.key}"/></span>
        <div class="bar-track"><div class="bar-fill" style="width:${e.value * 100 / maxMonth}%"></div></div>
        <span class="bar-value">${e.value}</span></div>
    </c:forEach>
    <c:if test="${empty byMonth}"><p class="text-muted mb-0">No data yet.</p></c:if>
  </div></div></div>
  <div class="col-lg-6"><div class="card"><div class="card-body">
    <h2 class="h6">Appointments per doctor (utilization)</h2>
    <c:forEach var="e" items="${byDoctor}">
      <div class="bar-row"><span class="bar-label"><c:out value="${e.key}"/></span>
        <div class="bar-track"><div class="bar-fill teal" style="width:${e.value * 100 / maxDoctor}%"></div></div>
        <span class="bar-value">${e.value}</span></div>
    </c:forEach>
    <c:if test="${empty byDoctor}"><p class="text-muted mb-0">No data yet.</p></c:if>
  </div></div></div>
  <div class="col-12"><div class="card"><div class="card-body">
    <h2 class="h6">Status distribution</h2>
    <c:forEach var="e" items="${byStatus}">
      <div class="bar-row"><span class="bar-label">${e.key}</span>
        <div class="bar-track"><div class="bar-fill" style="width:${e.value * 100 / maxStatus}%"></div></div>
        <span class="bar-value">${e.value}</span></div>
    </c:forEach>
    <c:if test="${empty byStatus}"><p class="text-muted mb-0">No data yet.</p></c:if>
  </div></div></div>
</div>
<%@ include file="/WEB-INF/views/common/footer.jsp" %>
