<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="Admin overview"/>
<%@ include file="/WEB-INF/views/common/header.jsp" %>
<h1 class="h4 mb-3">Overview</h1>
<div class="row g-3 mb-4">
  <div class="col-6 col-lg-4"><div class="card stat"><b>${totalUsers}</b><span>Registered users</span></div></div>
  <div class="col-6 col-lg-4"><div class="card stat t"><b>${totalDoctors}</b><span>Doctors</span></div></div>
  <div class="col-6 col-lg-4"><div class="card stat t"><b>${totalPatients}</b><span>Patients</span></div></div>
  <div class="col-6 col-lg-4"><div class="card stat"><b>${todayCount}</b><span>Appointments today</span></div></div>
  <div class="col-6 col-lg-4"><div class="card stat"><b><c:out value="${statusCounts['COMPLETED']}" default="0"/></b><span>Completed</span></div></div>
  <div class="col-6 col-lg-4"><div class="card stat"><b><c:out value="${statusCounts['CANCELLED']}" default="0"/></b><span>Cancelled</span></div></div>
</div>
<div class="card"><div class="card-body">
  <h2 class="h6">Latest appointments</h2>
  <table class="table table-sm">
    <thead><tr><th>ID</th><th>Patient</th><th>Doctor</th><th>Date</th><th>Status</th></tr></thead>
    <tbody>
    <c:forEach var="a" items="${recent}">
      <tr><td>A-${a.id}</td><td><c:out value="${a.patientName}"/></td><td><c:out value="${a.doctorName}"/></td>
          <td>${a.date} ${a.time}</td><td><span class="badge status-${a.status}">${a.status}</span></td></tr>
    </c:forEach>
    <c:if test="${empty recent}"><tr><td colspan="5" class="text-muted text-center">No appointments yet.</td></tr></c:if>
    </tbody>
  </table>
</div></div>
<%@ include file="/WEB-INF/views/common/footer.jsp" %>
