<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="pageTitle" value="User management"/>
<%@ include file="/WEB-INF/views/common/header.jsp" %>
<h1 class="h4 mb-3">User management</h1>
<div class="card mb-4"><div class="card-body">
  <h2 class="h6">Add user</h2>
  <form method="post" action="${ctx}/admin/users" class="row g-2">
    <input type="hidden" name="_csrf" value="<c:out value='${sessionScope.csrf}'/>">
    <input type="hidden" name="action" value="create">
    <div class="col-md-3"><label class="form-label" for="un">Name</label><input class="form-control" id="un" name="name" required maxlength="100"></div>
    <div class="col-md-3"><label class="form-label" for="ue">Email</label><input class="form-control" id="ue" name="email" type="email" required></div>
    <div class="col-md-2"><label class="form-label" for="up">Password (min 8)</label><input class="form-control" id="up" name="password" type="password" minlength="8" required autocomplete="new-password"></div>
    <div class="col-md-2"><label class="form-label" for="ur">Role</label>
      <select class="form-select" id="ur" name="role"><option>PATIENT</option><option>DOCTOR</option><option>ADMIN</option></select></div>
    <div class="col-md-2"><label class="form-label" for="us">Specialty (doctors)</label><input class="form-control" id="us" name="specialty" maxlength="80"></div>
    <div class="col-12"><button class="btn btn-primary" type="submit">Add user</button></div>
  </form>
</div></div>
<div class="card"><div class="card-body">
  <input type="search" class="form-control mb-3" style="max-width:320px" placeholder="Search users…" aria-label="Search users" data-filter-table="#userTable">
  <div class="table-responsive"><table class="table align-middle" id="userTable">
    <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead>
    <tbody>
    <c:forEach var="u" items="${users}">
      <tr>
        <td>U${u.id}</td><td><c:out value="${u.name}"/></td><td><c:out value="${u.email}"/></td>
        <td>${u.roleName}</td>
        <td><span class="badge ${u.active ? 'status-CONFIRMED' : 'status-CANCELLED'}">${u.status}</span></td>
        <td class="text-nowrap">
          <c:if test="${u.id != sessionScope.user.id}">
            <form method="post" action="${ctx}/admin/users" class="d-inline">
              <input type="hidden" name="_csrf" value="<c:out value='${sessionScope.csrf}'/>">
              <input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="${u.id}">
              <button class="btn btn-sm btn-outline-primary">${u.active ? 'Deactivate' : 'Activate'}</button>
            </form>
            <form method="post" action="${ctx}/admin/users" class="d-inline" data-confirm="Delete this user permanently?">
              <input type="hidden" name="_csrf" value="<c:out value='${sessionScope.csrf}'/>">
              <input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="${u.id}">
              <button class="btn btn-sm btn-outline-danger">Delete</button>
            </form>
          </c:if>
        </td>
      </tr>
    </c:forEach>
    </tbody>
  </table></div>
</div></div>
<%@ include file="/WEB-INF/views/common/footer.jsp" %>
