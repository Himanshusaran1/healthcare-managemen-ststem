<%-- Shared appointment table. Included by admin/doctor/patient pages; action buttons depend on ${role}. --%>
<div class="card"><div class="card-body">
  <input type="search" class="form-control mb-3" style="max-width:320px" placeholder="Search appointments…"
         aria-label="Search appointments" data-filter-table="#apptTable">
  <div class="table-responsive">
    <table class="table align-middle" id="apptTable">
      <thead><tr><th>ID</th><th>Patient</th><th>Doctor</th><th>Date</th><th>Time</th><th>Reason</th><th>Status</th><th>Actions</th></tr></thead>
      <tbody>
      <c:forEach var="a" items="${appointments}">
        <tr>
          <td>A-${a.id}</td>
          <td><c:out value="${a.patientName}"/></td>
          <td><c:out value="${a.doctorName}"/><br><small class="text-muted"><c:out value="${a.specialty}"/></small></td>
          <td>${a.date}</td><td>${a.time}</td>
          <td><c:out value="${a.reason}"/></td>
          <td><span class="badge status-${a.status}">${a.status}</span></td>
          <td class="text-nowrap">
            <c:if test="${a.open}">
              <c:if test="${a.status eq 'PENDING' and (role eq 'ADMIN' or role eq 'DOCTOR')}">
                <form method="post" action="${ctx}/appointments/status" class="d-inline">
                  <input type="hidden" name="_csrf" value="<c:out value='${sessionScope.csrf}'/>">
                  <input type="hidden" name="id" value="${a.id}"><input type="hidden" name="status" value="CONFIRMED">
                  <button class="btn btn-sm btn-primary">Confirm</button>
                </form>
              </c:if>
              <c:if test="${a.status eq 'CONFIRMED' and role eq 'DOCTOR'}">
                <form method="post" action="${ctx}/appointments/status" class="d-inline-flex gap-1">
                  <input type="hidden" name="_csrf" value="<c:out value='${sessionScope.csrf}'/>">
                  <input type="hidden" name="id" value="${a.id}"><input type="hidden" name="status" value="COMPLETED">
                  <input class="form-control form-control-sm" name="notes" placeholder="Consultation notes" aria-label="Consultation notes" maxlength="500">
                  <button class="btn btn-sm btn-success">Complete</button>
                </form>
              </c:if>
              <form method="post" action="${ctx}/appointments/status" class="d-inline" data-confirm="Cancel this appointment?">
                <input type="hidden" name="_csrf" value="<c:out value='${sessionScope.csrf}'/>">
                <input type="hidden" name="id" value="${a.id}"><input type="hidden" name="status" value="CANCELLED">
                <button class="btn btn-sm btn-outline-danger">Cancel</button>
              </form>
            </c:if>
          </td>
        </tr>
      </c:forEach>
      <c:if test="${empty appointments}"><tr><td colspan="8" class="text-center text-muted py-4">No appointments found.</td></tr></c:if>
      </tbody>
    </table>
  </div>
</div></div>
