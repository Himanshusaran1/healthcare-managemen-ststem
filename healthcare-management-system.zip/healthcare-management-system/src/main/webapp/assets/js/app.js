// Small progressive-enhancement helpers. All security checks happen on the server, not here.
document.addEventListener('DOMContentLoaded', function () {
  // Confirmation dialogs: <form data-confirm="Are you sure?">
  document.querySelectorAll('form[data-confirm]').forEach(function (form) {
    form.addEventListener('submit', function (e) {
      if (!window.confirm(form.dataset.confirm)) e.preventDefault();
    });
  });

  // Client-side table search: <input data-filter-table="#tableId">
  document.querySelectorAll('[data-filter-table]').forEach(function (input) {
    var table = document.querySelector(input.dataset.filterTable);
    if (!table) return;
    input.addEventListener('input', function () {
      var q = input.value.toLowerCase();
      table.querySelectorAll('tbody tr').forEach(function (row) {
        row.hidden = !row.textContent.toLowerCase().includes(q);
      });
    });
  });

  // Show/hide password on the login page
  var toggle = document.getElementById('togglePw');
  if (toggle) {
    toggle.addEventListener('click', function () {
      var field = document.getElementById('password');
      var show = field.type === 'password';
      field.type = show ? 'text' : 'password';
      toggle.textContent = show ? 'Hide' : 'Show';
    });
  }
});
