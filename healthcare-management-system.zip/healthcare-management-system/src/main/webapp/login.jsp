<%@ page contentType="text/html;charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Sign in – CareLink</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="${ctx}/assets/css/style.css" rel="stylesheet">
</head>
<body class="login-bg">
<main class="container d-flex align-items-center justify-content-center min-vh-100">
  <form class="card shadow-sm p-4" style="max-width:400px;width:100%" method="post" action="${ctx}/login" novalidate>
    <h1 class="h4 brand mb-1">Care<b>Link</b></h1>
    <p class="text-muted">Sign in to your dashboard</p>
    <c:if test="${not empty error}"><div class="alert alert-danger" role="alert"><c:out value="${error}"/></div></c:if>
    <div class="mb-3">
      <label class="form-label" for="email">Email</label>
      <input class="form-control" id="email" name="email" type="email" autocomplete="username" required value="<c:out value='${email}'/>">
    </div>
    <div class="mb-3">
      <label class="form-label" for="password">Password</label>
      <div class="input-group">
        <input class="form-control" id="password" name="password" type="password" autocomplete="current-password" required>
        <button class="btn btn-outline-secondary" type="button" id="togglePw" aria-label="Show or hide password">Show</button>
      </div>
    </div>
    <button class="btn btn-primary w-100" type="submit">Sign in</button>
    <p class="small text-muted mt-3 mb-0">You are redirected to the dashboard that matches your account role.</p>
  </form>
</main>
<script src="${ctx}/assets/js/app.js"></script>
</body>
</html>
