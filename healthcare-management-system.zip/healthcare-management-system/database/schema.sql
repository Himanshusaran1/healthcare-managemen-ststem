-- Online Healthcare Management System - MySQL 8.0+ schema
-- Run:  mysql -u root -p < database/schema.sql
-- Sample users are NOT inserted here: passwords must be BCrypt hashes, which the
-- development seeder (DevSeeder.java) creates from db.properties.

CREATE DATABASE IF NOT EXISTS healthcare_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE healthcare_db;

CREATE TABLE IF NOT EXISTS users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  email         VARCHAR(120) NOT NULL,
  password_hash VARCHAR(100) NOT NULL,              -- BCrypt hash only, never plaintext
  role          ENUM('ADMIN','DOCTOR','PATIENT') NOT NULL,
  status        ENUM('ACTIVE','INACTIVE') NOT NULL DEFAULT 'ACTIVE',
  phone         VARCHAR(20),
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT uq_users_email UNIQUE (email),
  INDEX idx_users_role (role)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS doctors (
  id        INT AUTO_INCREMENT PRIMARY KEY,
  user_id   INT NOT NULL,
  specialty VARCHAR(80) NOT NULL,
  bio       VARCHAR(255),
  CONSTRAINT uq_doctors_user UNIQUE (user_id),
  CONSTRAINT fk_doctors_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_doctors_specialty (specialty)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS patients (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  user_id       INT NOT NULL,
  date_of_birth DATE,
  address       VARCHAR(255),
  blood_group   VARCHAR(5),
  CONSTRAINT uq_patients_user UNIQUE (user_id),
  CONSTRAINT fk_patients_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS appointments (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  doctor_id  INT NOT NULL,
  appt_date  DATE NOT NULL,
  appt_time  TIME NOT NULL,
  reason     VARCHAR(255) NOT NULL,
  status     ENUM('PENDING','CONFIRMED','COMPLETED','CANCELLED') NOT NULL DEFAULT 'PENDING',
  notes      TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_appt_patient FOREIGN KEY (patient_id) REFERENCES patients(id),
  CONSTRAINT fk_appt_doctor  FOREIGN KEY (doctor_id)  REFERENCES doctors(id),
  -- Double booking is prevented in AppointmentService (row lock + check inside a transaction);
  -- cancelled slots must be re-bookable, so this is an index, not a UNIQUE constraint.
  INDEX idx_appt_slot (doctor_id, appt_date, appt_time),
  INDEX idx_appt_patient (patient_id),
  INDEX idx_appt_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS doctor_availability (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  doctor_id   INT NOT NULL,
  day_of_week TINYINT NOT NULL,                      -- 1 = Monday ... 7 = Sunday
  start_time  TIME NOT NULL,
  end_time    TIME NOT NULL,
  CONSTRAINT fk_avail_doctor FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE,
  CONSTRAINT uq_avail UNIQUE (doctor_id, day_of_week, start_time),
  CONSTRAINT chk_avail_day CHECK (day_of_week BETWEEN 1 AND 7)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS medical_records (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  doctor_id  INT NOT NULL,                           -- responsible doctor
  diagnosis  VARCHAR(255) NOT NULL,
  allergies  VARCHAR(255),
  notes      TEXT,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_rec_patient FOREIGN KEY (patient_id) REFERENCES patients(id),
  CONSTRAINT fk_rec_doctor  FOREIGN KEY (doctor_id)  REFERENCES doctors(id),
  INDEX idx_rec_patient (patient_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS prescriptions (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  record_id  INT NOT NULL,
  medication VARCHAR(120) NOT NULL,
  dosage     VARCHAR(120),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_presc_record FOREIGN KEY (record_id) REFERENCES medical_records(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS patient_feedback (
  id             INT AUTO_INCREMENT PRIMARY KEY,
  appointment_id INT NOT NULL,
  patient_id     INT NOT NULL,
  doctor_id      INT NOT NULL,
  rating         TINYINT NOT NULL,
  comment        VARCHAR(500),
  created_at     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_feedback_appt UNIQUE (appointment_id),
  CONSTRAINT fk_fb_appt    FOREIGN KEY (appointment_id) REFERENCES appointments(id),
  CONSTRAINT fk_fb_patient FOREIGN KEY (patient_id) REFERENCES patients(id),
  CONSTRAINT fk_fb_doctor  FOREIGN KEY (doctor_id)  REFERENCES doctors(id),
  CONSTRAINT chk_fb_rating CHECK (rating BETWEEN 1 AND 5),
  INDEX idx_fb_doctor (doctor_id, created_at)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS system_settings (
  setting_key   VARCHAR(60) PRIMARY KEY,
  setting_value VARCHAR(255) NOT NULL,
  updated_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT IGNORE INTO system_settings (setting_key, setting_value) VALUES
  ('hospital_name', 'CareLink General Hospital'),
  ('contact_email', 'info@carelink.test'),
  ('appointment_duration_minutes', '30'),
  ('notifications_email', 'true');
