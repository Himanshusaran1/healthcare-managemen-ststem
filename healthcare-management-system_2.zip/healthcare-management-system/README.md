# Online Healthcare Management System

A Java web application with separate **Admin**, **Doctor** and **Patient** dashboards.
Built with JSP, Servlets, JDBC, MySQL and Bootstrap 5, organised as MVC
(`controller` → `service` → `dao` → MySQL, with JSP views).

## Status (read this first)

The Java code compiles against the servlet and BCrypt APIs (checked with stub classes), but it has **not yet been run
against a real MySQL server and Tomcat**. Follow the setup steps below and test each feature before relying on it.

| Area | State |
|---|---|
| Login, logout, role-based redirect, session security, CSRF token | Implemented (needs your testing) |
| Server-side role checks (`AuthFilter`) and ownership checks in services | Implemented (needs your testing) |
| Admin: dashboard counts, add / activate / deactivate / delete users, view and manage all appointments | Implemented |
| Doctor: dashboard, confirm / complete / cancel appointments with notes, patient records with prescriptions | Implemented |
| Patient: dashboard, booking with generated free slots, history and cancel, read-only medical timeline | Implemented |
| Double-booking prevention (row lock + re-check inside a transaction) | Implemented |
| Not yet built | System settings screen, analytics charts, doctor availability editor, patient feedback screens, profile / change password, rescheduling, server-side pagination |

The database tables for the items not yet built already exist in `database/schema.sql`.
`prototype/healthcare-prototype.html` is the original mock-data UI design (open it in a browser; it does not use the backend).

## 1. Requirements

| Tool | Version |
|---|---|
| JDK | 17 or newer |
| Maven | 3.9 or newer |
| MySQL | 8.0 or newer |
| Apache Tomcat | **10.1.x** (uses the `jakarta.*` packages; Tomcat 9 will not work) |

## 2. Create the database

```bash
mysql -u root -p < database/schema.sql
```

This creates the `healthcare_db` database, all tables, and default system settings.

## 3. Configure the database connection

```bash
cp src/main/resources/db.properties.example src/main/resources/db.properties
```

Edit `db.properties` and set `db.user` and `db.password`. The file is git-ignored so your password is not committed.

## 4. Development-only sample accounts

In `db.properties`:

```
seed.dev.users=true
seed.dev.password=ChooseYourOwnPassword#1
```

On startup, if the `users` table is empty, the app creates these accounts (password hashed with BCrypt, never stored in plaintext):

| Role | Email |
|---|---|
| Admin | admin@healthcare.test |
| Doctor | dr.mehta@healthcare.test, dr.iqbal@healthcare.test |
| Patient | riya@healthcare.test, neha@healthcare.test |

Doctors get Monday to Friday, 09:00-13:00 availability so patients can book slots.
**Set `seed.dev.users=false` after the first run and never enable it on a real server.** You can also create users from the Admin dashboard.

## 5. Build

```bash
mvn clean package
```

Output: `target/healthcare-management-system.war`

## 6. Deploy to Tomcat

Copy the WAR into `<TOMCAT_HOME>/webapps/` and start Tomcat (`bin/startup.sh` or `bin/startup.bat`).
In IntelliJ IDEA or Eclipse you can instead add a Tomcat 10.1 run configuration and deploy the WAR / exploded artifact.

## 7. Open the app

http://localhost:8080/healthcare-management-system/

Log in with one of the sample accounts. You are redirected to the dashboard for your role.

## 8. Troubleshooting

| Problem | What to check |
|---|---|
| `db.properties not found` in the Tomcat log | You did not copy `db.properties.example` to `db.properties` before building. Rebuild after creating it. |
| `Access denied for user` / `Communications link failure` | Check `db.user`, `db.password` and `db.url`; confirm MySQL is running on port 3306. |
| `Unknown database 'healthcare_db'` | Run step 2 (`schema.sql`). |
| `ClassNotFoundException: javax.servlet...` or blank pages | You are on Tomcat 9. Use Tomcat 10.1. |
| JSP shows `${...}` as text or JSTL error | Rebuild with `mvn clean package`; the JSTL libraries must be inside the WAR. |
| No time slots when booking | The doctor has no availability for that weekday (sample doctors work Mon-Fri). |
| 404 on every page | Use the context path in the URL: `/healthcare-management-system/`. |
| Port 8080 in use | Change the Tomcat connector port in `conf/server.xml`. |

## How the frontend connects to Java and MySQL

1. The browser requests a URL such as `/doctor/appointments`.
2. `AuthFilter` checks the session, the role for that URL prefix, and the CSRF token on POSTs.
3. A servlet (`controller/`) reads the request and calls a service.
4. The service (`service/`) applies business rules (validation, ownership, double-booking checks).
5. A DAO (`dao/`) runs prepared-statement SQL over JDBC against MySQL.
6. The servlet puts the results in the request and forwards to a JSP in `WEB-INF/views/`, which renders HTML with `<c:out>` escaping.

## Security notes

- Passwords: BCrypt (cost 12) via jBCrypt. Login failures return one generic message.
- Sessions: new session ID on login, HttpOnly cookie, cookie-only tracking, 30-minute timeout, no-store cache headers.
- Authorization is enforced on the server (filter + service ownership checks), not by hiding menu items.
- All SQL uses prepared statements; JSP output uses `<c:out>`.
- Before using this beyond a demo: serve over HTTPS and add `<secure>true</secure>` to the session cookie, add login rate limiting, and use a connection pool.

## Project structure

```
src/main/java/com/healthcare/{controller,service,dao,model,filter,util}
src/main/webapp/{assets,WEB-INF/views/{admin,doctor,patient,common,error}}, login.jsp, index.jsp
database/schema.sql
prototype/healthcare-prototype.html
pom.xml
```
