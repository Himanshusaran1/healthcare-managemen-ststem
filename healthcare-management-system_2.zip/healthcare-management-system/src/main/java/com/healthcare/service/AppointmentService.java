package com.healthcare.service;

import com.healthcare.dao.AppointmentDAO;
import com.healthcare.dao.DoctorDAO;
import com.healthcare.dao.SettingsDAO;
import com.healthcare.model.Appointment;
import com.healthcare.model.Availability;
import com.healthcare.model.User;
import com.healthcare.util.AppException;
import com.healthcare.util.DBUtil;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

/** Business rules for appointments: slot generation, double-booking protection, status changes. */
public class AppointmentService {
    private final AppointmentDAO dao = new AppointmentDAO();
    private final DoctorDAO doctorDao = new DoctorDAO();
    private final SettingsDAO settings = new SettingsDAO();

    // ---------- listing and dashboard helpers ----------

    public List<Appointment> listFor(User u) {
        return switch (u.getRole()) {
            case ADMIN -> dao.findAll();
            case DOCTOR -> dao.findByDoctor(u.getProfileId());
            case PATIENT -> dao.findByPatient(u.getProfileId());
        };
    }

    public Map<String, Long> statusCounts(List<Appointment> list) {
        return list.stream().collect(Collectors.groupingBy(Appointment::getStatus, TreeMap::new, Collectors.counting()));
    }

    public long countToday(List<Appointment> list) {
        LocalDate today = LocalDate.now();
        return list.stream().filter(a -> a.getDate().equals(today) && !"CANCELLED".equals(a.getStatus())).count();
    }

    /** Open appointments from today onwards, soonest first. */
    public List<Appointment> upcoming(List<Appointment> list) {
        LocalDate today = LocalDate.now();
        return list.stream()
            .filter(a -> a.isOpen() && !a.getDate().isBefore(today))
            .sorted(Comparator.comparing(Appointment::getDate).thenComparing(Appointment::getTime))
            .collect(Collectors.toList());
    }

    public long distinctPatients(List<Appointment> list) {
        return list.stream().map(Appointment::getPatientId).distinct().count();
    }

    // ---------- slot generation ----------

    /** Free times for a doctor on a date, built from their availability windows minus existing bookings. */
    public List<LocalTime> availableSlots(int doctorId, LocalDate date) {
        if (date.isBefore(LocalDate.now())) return List.of();
        int minutes = parseDuration(settings.get("appointment_duration_minutes", "30"));
        Set<LocalTime> booked = dao.bookedTimes(doctorId, date);
        LocalTime now = LocalTime.now();
        TreeSet<LocalTime> slots = new TreeSet<>();
        for (Availability w : doctorDao.availability(doctorId, date.getDayOfWeek().getValue())) {
            for (LocalTime t = w.getStart(); !t.plusMinutes(minutes).isAfter(w.getEnd()); t = t.plusMinutes(minutes)) {
                boolean past = date.equals(LocalDate.now()) && !t.isAfter(now);
                if (!booked.contains(t) && !past) slots.add(t);
            }
        }
        return new ArrayList<>(slots);
    }

    private int parseDuration(String value) {
        try {
            int m = Integer.parseInt(value);
            return m >= 5 && m <= 240 ? m : 30;
        } catch (NumberFormatException e) {
            return 30;
        }
    }

    // ---------- booking (transactional, prevents double booking) ----------

    public int book(int patientId, int doctorId, LocalDate date, LocalTime time, String reason) {
        if (reason == null || reason.isBlank()) throw new AppException("Please enter the reason for your visit.");
        if (reason.length() > 255) throw new AppException("Reason must be 255 characters or fewer.");
        if (!availableSlots(doctorId, date).contains(time)) throw new AppException("That time is not available. Please pick another slot.");

        try (Connection c = DBUtil.getConnection()) {
            c.setAutoCommit(false);
            try {
                if (!dao.lockDoctor(c, doctorId)) throw new AppException("Doctor not found.");
                // Re-check inside the lock: another patient may have booked this slot a moment ago.
                if (dao.slotTaken(c, doctorId, date, time)) throw new AppException("That slot was just booked. Please choose another.");
                int id = dao.insert(c, patientId, doctorId, date, time, reason.trim());
                c.commit();
                return id;
            } catch (SQLException | RuntimeException e) {
                c.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new AppException("Could not book the appointment. Please try again.", e);
        }
    }

    // ---------- status changes with role + ownership checks ----------

    public void changeStatus(User actor, int appointmentId, String newStatus, String notes) {
        Appointment a = dao.findById(appointmentId).orElseThrow(() -> new AppException("Appointment not found."));

        // Ownership: report "not found" so appointment IDs cannot be probed.
        boolean owns = switch (actor.getRole()) {
            case ADMIN -> true;
            case DOCTOR -> a.getDoctorId() == actor.getProfileId();
            case PATIENT -> a.getPatientId() == actor.getProfileId();
        };
        if (!owns) throw new AppException("Appointment not found.");

        Set<String> allowed = switch (actor.getRole()) {
            case ADMIN -> Set.of("CONFIRMED", "CANCELLED");
            case DOCTOR -> Set.of("CONFIRMED", "COMPLETED", "CANCELLED");
            case PATIENT -> Set.of("CANCELLED");
        };
        if (newStatus == null || !allowed.contains(newStatus)) throw new AppException("You cannot do that.");
        if (!a.isOpen()) throw new AppException("This appointment is already " + a.getStatus().toLowerCase() + ".");
        if ("COMPLETED".equals(newStatus) && !"CONFIRMED".equals(a.getStatus())) {
            throw new AppException("Only confirmed appointments can be completed.");
        }
        String cleanNotes = (notes == null || notes.isBlank() || actor.getRole() != com.healthcare.model.Role.DOCTOR) ? null : notes.trim();
        dao.updateStatus(appointmentId, newStatus, cleanNotes);
    }
}
