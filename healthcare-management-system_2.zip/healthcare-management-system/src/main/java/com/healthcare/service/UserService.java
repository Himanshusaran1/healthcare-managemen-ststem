package com.healthcare.service;

import com.healthcare.dao.UserDAO;
import com.healthcare.model.Role;
import com.healthcare.model.User;
import com.healthcare.util.AppException;
import com.healthcare.util.PasswordUtil;

import java.util.List;
import java.util.regex.Pattern;

/** Admin-side user management with server-side validation. */
public class UserService {
    private static final Pattern EMAIL = Pattern.compile("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");
    private final UserDAO userDao = new UserDAO();

    public List<User> list() { return userDao.findAll(); }

    public long countByRole(List<User> users, Role role) {
        return users.stream().filter(u -> u.getRole() == role).count();
    }

    public void create(String name, String email, String password, String roleText, String specialty) {
        if (name == null || name.trim().length() < 2 || name.length() > 100) throw new AppException("Enter a name (2-100 characters).");
        if (email == null || !EMAIL.matcher(email.trim()).matches()) throw new AppException("Enter a valid email address.");
        if (password == null || password.length() < 8) throw new AppException("Password must be at least 8 characters.");
        Role role = Role.parse(roleText);

        User u = new User();
        u.setName(name.trim());
        u.setEmail(email.trim().toLowerCase());
        u.setRole(role);
        userDao.create(u, PasswordUtil.hash(password), specialty == null ? null : specialty.trim());
    }

    public void delete(User actor, int userId) {
        if (actor.getId() == userId) throw new AppException("You cannot delete your own account.");
        userDao.delete(userId);
    }

    public void toggleStatus(User actor, int userId) {
        if (actor.getId() == userId) throw new AppException("You cannot deactivate your own account.");
        User target = userDao.findById(userId).orElseThrow(() -> new AppException("User not found."));
        userDao.setStatus(userId, target.isActive() ? "INACTIVE" : "ACTIVE");
    }
}
