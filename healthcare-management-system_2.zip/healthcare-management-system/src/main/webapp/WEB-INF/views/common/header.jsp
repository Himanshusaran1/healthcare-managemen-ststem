<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<c:set var="ctx" value="${pageContext.request.contextPath}"/>
<c:set var="role" value="${sessionScope.user.roleName}"/>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title><c:out value="${pageTitle}"/> – CareLink</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="${ctx}/assets/css/style.css" rel="stylesheet">
</head>
<body>
<div class="app">
  <aside class="sidebar">
    <div class="brand p-3">Care<b>Link</b></div>
    <nav class="nav flex-column px-2" aria-label="Main">
      <c:choose>
        <c:when test="${role eq 'ADMIN'}">
          <a class="nav-link" href="${ctx}/admin/dashboard">Overview</a>
          <a class="nav-link" href="${ctx}/admin/users">User management</a>
          <a class="nav-link" href="${ctx}/admin/appointments">Appointments</a>
        </c:when>
        <c:when test="${role eq 'DOCTOR'}">
          <a class="nav-link" href="${ctx}/doctor/dashboard">Overview</a>
          <a class="nav-link" href="${ctx}/doctor/appointments">Appointments</a>
          <a class="nav-link" href="${ctx}/doctor/records">Patient records</a>
        </c:when>
        <c:otherwise>
          <a class="nav-link" href="${ctx}/patient/dashboard">Overview</a>
          <a class="nav-link" href="${ctx}/patient/book">Book appointment</a>
          <a class="nav-link" href="${ctx}/patient/history">Appointment history</a>
          <a class="nav-link" href="${ctx}/patient/medical">Medical history</a>
        </c:otherwise>
      </c:choose>
    </nav>
  </aside>
  <main class="content">
    <div class="d-flex justify-content-end align-items-center gap-3 mb-3">
      <span><c:out value="${sessionScope.user.name}"/> <span class="badge bg-info text-dark"><c:out value="${role}"/></span></span>
      <form method="post" action="${ctx}/logout" class="m-0">
        <input type="hidden" name="_csrf" value="<c:out value='${sessionScope.csrf}'/>">
        <button class="btn btn-sm btn-outline-primary" type="submit">Log out</button>
      </form>
    </div>
    <c:if test="${not empty sessionScope.flash}">
      <div class="alert alert-${sessionScope.flashType eq 'danger' ? 'danger' : 'success'}" role="alert"><c:out value="${sessionScope.flash}"/></div>
      <c:remove var="flash" scope="session"/><c:remove var="flashType" scope="session"/>
    </c:if>
